import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import axios from "axios";

const GRAMatrixPage = () => {
  const { userId } = useParams();
  const navigate = useNavigate();

  const [roles, setRoles] = useState([]);
  const [agents, setAgents] = useState([]);
  const [evaluations, setEvaluations] = useState({});
  const [matrix, setMatrix] = useState([]);
  const [user, setUser] = useState({});
  const [loading, setLoading] = useState(true);
  const [useConflicts, setUseConflicts] = useState(false);
  const [conflictMatrixExists, setConflictMatrixExists] = useState(true);
  const [conflictError, setConflictError] = useState("");

  useEffect(() => {
    if (!userId) return;

    async function fetchMatrix() {
      try {
        const res = await axios.get(`/api/assignments/GRA/matrix/${userId}`);
        setRoles(res.data.roles || []);
        setAgents(res.data.agents || []);
        setEvaluations(res.data.evaluations || {});
        setMatrix(res.data.matrix || []);
        setUser(res.data.user || {});
      } catch (err) {
        console.error("Failed to load matrix data", err.response?.data || err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchMatrix();
  }, [userId]);

  useEffect(() => {
    if (!userId) return;

    async function checkConflictMatrix() {
      try {
        await axios.get(`/api/assignments/conflicts/${userId}`);
        setConflictMatrixExists(true);
      } catch (err) {
        if (err.response?.status === 404) {
          setConflictError(err.response.data?.detail || "Conflict matrix not defined.");
          setConflictMatrixExists(false);
        } else {
          setConflictError("An unexpected error occurred.");
          setConflictMatrixExists(false);
        }
      }
    }

    checkConflictMatrix();
  }, [userId]);

  const handleConsiderConflicts = async () => {
    try {
      const res = await axios.post(`/api/assignments/GRA/consider_cooperation/${userId}`);
      if (res.data.matrix){
        setMatrix(res.data.matrix);
        setUseConflicts(true); 
        alert("Optimal results considering conflicts received.") 
      }
      else{
        alert("Too many conflicts to produce results. Consider lowering the amount of roles or removing some conflicts.")
      }
    } catch (err) {
      console.error("Failed to apply conflict-aware assignment", err);
      alert("Could not apply conflict-aware assignment.");
    }
  }

  const handleExport = () => {
    let output = `Role Assignments for ${user.COMPANY_NAME} – ${user.DEPARTMENT}\n\n`;

    roles.forEach((role, colIdx) => {
      const assignedAgents = agents
        .filter((_, rowIdx) => matrix?.[rowIdx]?.[colIdx] === 1)
        .map(agent => `${agent.FIRST_NAME} ${agent.LAST_NAME}`);

      if (assignedAgents.length > 0) {
        output += `${role.ROLE_NAME}:\n`;
        assignedAgents.forEach(agentName => {
          output += `  - ${agentName}\n`;
        });
        output += '\n';
      }
    });
    
    const blob = new Blob([output], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `GRA_Assignment_${user.COMPANY_NAME}_${user.DEPARTMENT}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return <div>Loading Assignment Matrix...</div>;
  if (!userId) return <div>Error: Missing user ID</div>;

  return (
    <div>
      <h2>Group Role Assignment Results</h2>

      <div style={{ marginBottom: "1rem" }}>
        <button
          className="upload-button"
          style={{
            backgroundColor: conflictMatrixExists ? "#cf2525" : "#888",
            color: "white",
            marginTop: "1rem",
            cursor: conflictMatrixExists ? "pointer" : "not-allowed",
            pointerEvents: conflictMatrixExists ? "auto" : "none"
          }}
          onClick={handleConsiderConflicts}
        >
          Consider Conflicts
        </button>

        {!conflictMatrixExists && (
          <div style={{ marginTop: "0.5rem", color: "#555", fontStyle: "italic" }}>
            Please identify agent statuses by clicking the "Agent Statuses" section of the account options
          </div>
        )}
      </div>
      <br />

      <div className="text-section">
        <table className="evaluation-table">
          <thead>
            <tr>
              <th className="diagonal-header">
                <div className="top-left-text">Roles</div>
                <div className="bottom-right-text">Agents</div>
              </th>
              {roles.map((role) => (
                <th key={role.ROLE_NAME}>{role.ROLE_NAME}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {agents.map((agent, rowIdx) => {
              const agentKey = agent.AGENT_NUM;
              return (
                <tr key={agentKey}>
                  <td>{agent.FIRST_NAME} {agent.LAST_NAME}</td>
                  {roles.map((role, colIdx) => {
                    const score = evaluations?.[agentKey]?.[role.ROLE_NAME] ?? 0;
                    const isAssigned = matrix?.[rowIdx]?.[colIdx] === 1;

                    return (
                      <td
                        key={role.ROLE_NAME}
                        style={{
                          backgroundColor: isAssigned ? "#5a4864" : "transparent",
                          color: isAssigned ? "#ffffff" : "#000000"
                        }}
                      >
                        {score.toFixed(2)}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>

        <div className="button-box">
          <button className="upload-button" style={{ marginLeft: "1rem" }} onClick={handleExport}>
            Export Results
          </button>
          <Link to="../assignment/GRA1">
            <button className="upload-button" style={{ backgroundColor: "#ccc" }}>
              Return to Assignment Setup
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default GRAMatrixPage;