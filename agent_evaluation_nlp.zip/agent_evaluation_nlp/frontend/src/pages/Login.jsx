import React, { useState } from 'react';
import '../styles/login.css';
import { useAuth } from '../components/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function LoginPage() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    // ADD LOGIC LATER
    const simulatedUserId = 1; // replace with real API logic
    login(simulatedUserId);

    console.log('Logging in as user ID:', simulatedUserId);
    navigate('/');
  };

  const handleSignUp = (e) => {
    e.preventDefault();
    // Call backend to create user
    console.log('Signing up...');
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={isSignUp ? handleSignUp : handleLogin}>
        <h2>{isSignUp ? 'Sign Up' : 'Login'}</h2>

        <input type="email" placeholder="Email" required />
        <input  type="password" placeholder="Password" required />

        {isSignUp && <input type="text" placeholder="Full Name" required />}

        <button type="submit">{isSignUp ? 'Sign Up' : 'Login'}</button>

        <p>
          {isSignUp ? 'Already have an account?' : "Don't have an account?"}
          <button
            type="button"
            className="link-button"
            onClick={() => setIsSignUp(!isSignUp)}
          >
            {isSignUp ? 'Login' : 'Sign Up'}
          </button>
        </p>
      </form>
    </div>
  );
}