'''
In this module, each document identifies the agents to be evaluated
the data is preprocessed to remove unnecessary noise
'''
import pprint as pp
import spacy
import re
from services.data.LoadingPipeline import load_all_files
from pprint import pprint
from rapidfuzz import fuzz
import hashlib
import json
import pandas as pd
import datetime

# loading NLP 
nlp = spacy.load("en_core_web_sm")
nlp.max_length = 4_000_000  

def convert_timestamps(obj):
    if isinstance(obj, dict):
        return {k: convert_timestamps(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_timestamps(v) for v in obj]
    elif isinstance(obj, (pd.Timestamp, datetime.datetime)):
        return obj.isoformat()
    else:
        return obj

def calculate_hash(data):
    clean_data = convert_timestamps(data)
    data_bytes = json.dumps(clean_data, sort_keys=True).encode('utf-8')
    return hashlib.sha256(data_bytes).hexdigest()

#trying NLP to get names   
def detect_agents_ner(text, agents_list=None, id_list=None, fuzzy_threshold=85):
    if not agents_list or not id_list:
        return [], []

    doc = nlp(text)
    detected_names = []
    detected_ids = []
    seen_ids = set()
    text_tokens = set(text.split())
    text_lower = text.lower()

    # Prepare lowercase name map for quick access
    name_to_id = {name: agent_id for name, agent_id in zip(agents_list, id_list) if name and agent_id}
    lower_name_map = {name.lower(): agent_id for name, agent_id in name_to_id.items()}

    # 1. Exact + fuzzy on spaCy PERSON ents
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            ent_text = ent.text.strip()
            ent_text_lower = ent_text.lower()

            for name_lower, agent_id in lower_name_map.items():
                if agent_id in seen_ids:
                    continue

                # Exact match ignoring case
                if re.fullmatch(rf"\b{re.escape(name_lower)}\b", ent_text_lower):
                    detected_names.append(name_lower)
                    detected_ids.append(agent_id)
                    seen_ids.add(agent_id)
                    break
                else:
                    similarity = fuzz.token_set_ratio(ent_text_lower, name_lower)
                    if similarity >= fuzzy_threshold:
                        detected_names.append(name_lower)
                        detected_ids.append(agent_id)
                        seen_ids.add(agent_id)
                        break

    # 2. Match agent ID as literal token
    for name, agent_id in name_to_id.items():
        if agent_id in seen_ids:
            continue
        if str(agent_id) in text_tokens:
            detected_names.append(name)
            detected_ids.append(agent_id)
            seen_ids.add(agent_id)

    # 3. Fuzzy match full name fallback
    for name, agent_id in name_to_id.items():
        if agent_id in seen_ids:
            continue
        similarity = fuzz.token_set_ratio(name.lower(), text_lower)
        if similarity >= fuzzy_threshold:
            detected_names.append(name)
            detected_ids.append(agent_id)
            seen_ids.add(agent_id)

    return detected_names, detected_ids

# preprocess the content 
def preprocess_text(text_dict):
    if isinstance(text_dict, dict):
        # Concatenate all values (converted to lowercase strings)
        cleaned_text = " ".join(str(value).lower() for value in text_dict.values())
        return cleaned_text.strip()
    elif isinstance(text_dict, str):
        # Just return lowercase trimmed string
        return text_dict.lower().strip()
    elif text_dict is None:
        # Return empty string for None
        return ""
    else:
        # For other types, convert to string and lowercase
        return str(text_dict).lower().strip()
    
# takes documents and formats them into required format
def format_data(data, agents=None, ids=None):
    structured_data = []

    for file in data:
        category = file["category"]
        text = file["text"]

        if isinstance(text, list):  # Already parsed rows from Excel/CSV
            document_entries = text  # List of dicts
            # Add hash to each entry
            document_entries = [
                {**entry, "_hash": calculate_hash(entry)} for entry in document_entries
            ]
            search_text = " ".join(" ".join(str(v) for v in row.values()) for row in text)
        elif isinstance(text, dict):
            document_entries = [text]
            document_entries = [
                {**entry, "_hash": calculate_hash(entry)} for entry in document_entries
            ]
            search_text = " ".join(str(v) for v in text.values())
        else:  # raw string
            preprocessed = preprocess_text(text)
            # Wrap string in dict to add hash consistently
            document_entries = [{"text": preprocessed, "_hash": calculate_hash(preprocessed)}]
            search_text = preprocessed
            print(preprocessed)
            print(search_text)
       
        detected_agents, detected_ids = detect_agents_ner(search_text, agents, ids)

        for agent_name, agent_id in zip(detected_agents, detected_ids):
            existing_agent = next(
                (item for item in structured_data if item["agent_id"] == agent_id and item["agent_name"] == agent_name),
                None
            )

            if existing_agent:
                existing_agent["documents"].setdefault(category, []).extend(document_entries)
            else:
                structured_data.append({
                    "agent_name": agent_name,
                    "agent_id": agent_id,
                    "documents": {
                        category: document_entries
                    }
                })

    return structured_data


